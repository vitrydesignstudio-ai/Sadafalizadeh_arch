SHEET by SADAF — Beta 0.1.3
ساخته شده توسط صدف عریزاده

ساختار پیشنهادی نصب:
1) کل فولدر «SHEET by SADAF» را در یک مسیر ثابت نگه دارید؛ پیشنهاد: یکی از مسیرهای Support اتوکد.
2) داخل AutoCAD دستور APPLOAD را اجرا کنید و فایل SheetBySadaf.lsp را Load کنید.
3) برای Load خودکار در دفعات بعد:
   APPLOAD > Startup Suite > Contents > Add
   سپس SheetBySadaf.lsp را انتخاب کنید.
4) فقط بار اول دستور SCTBINSTALL را اجرا کنید تا CTBهای همراه ابزار نصب شوند.
5) برای Plot از دستور SPLOT استفاده کنید.

دستورات اصلی:
SPLOT      Batch Plot
SLAYOUT    ساخت Layout از شیت‌های Model Space
SCTB       مدیریت CTB / Scale
SCTBINSTALL نصب CTBهای همراه
SSET       تنظیمات

خروجی PDF:
در مرحله آخر می‌توانید بین PDFهای جداگانه و یک PDF چندصفحه‌ای انتخاب کنید.

راهنمای کامل:
پوشه Guide شامل نسخه PowerPoint و PDF راهنمای فارسی است.
