;;; ================================================================
;;; SHEET by SADAF
;;; Smart batch plotting tools for AutoCAD
;;; Beta 0.1.3 — 2026
;;; Built by: Sadaf Arizadeh / ساخته شده توسط صدف عریزاده
;;; ================================================================
;;; Commands:
;;;   SPLOT        Batch plot from Model Space sheets or Layouts
;;;   SCTB         Apply a CTB profile to the current tab
;;;   SCTBINSTALL  Install bundled CTB files into AutoCAD Plot Styles
;;;   SSET         Show current plotting configuration / paths
;;;   SLAYOUT      Experimental: create Layouts from detected Model sheets
;;;
;;; Primary workflow:
;;;   1) Configure the current Model tab once (printer, media, orientation, scale).
;;;   2) Run SPLOT.
;;;   3) Choose Model.
;;;   4) Select the first sheet frame/title block.
;;;   5) SHEET by SADAF detects matching sheets, sorts them, and asks for Separate PDFs or one Multi-sheet PDF.
;;;
;;; Notes:
;;; - The Model workflow learns geometry from the first selected sheet.
;;; - If the selected object is a block, matching effective block names are detected.
;;; - If it is a closed polyline, matching closed polylines of the same size are detected.
;;; - Plot settings are inherited from the current tab; CTB can optionally be overridden.
;;; - v0.1.3 adds native AutoCAD multi-sheet PDF publishing (no external PDF merger).
;;; ================================================================

(vl-load-com)

(setq *SBS:VERSION* "0.1.3")

;;; -----------------------------
;;; Profile definitions
;;; -----------------------------
;;; Each profile uses a CTB bundled with this beta.
;;; ARCH_50 and ARCH_100 are added in v0.1.2 after first real plot feedback.
(setq *SBS:CTB-PROFILES*
  '(
    ("ARCH_50"        . "ARCH_50.ctb")
    ("ARCH_100"       . "ARCH_100.ctb")
    ("ARCH_200"       . "ARCH_200.ctb")
    ("ARCH_300"       . "ARCH_300.ctb")
    ("ARCH_300_ALT"   . "ARCH_300_ALT.ctb")
    ("ARCH_500"       . "ARCH_500.ctb")
    ("SITE_500"       . "SITE_500.ctb")
    ("STRUCT_A4"      . "STRUCT_A4.ctb")
    ("COMMERCIAL_A3"  . "COMMERCIAL_A3.ctb")
    ("VIEW"           . "VIEW.ctb")
  )
)

;;; -----------------------------
;;; Generic helpers
;;; -----------------------------
(defun SBS:msg (s)
  (princ (strcat "\n[SHEET by SADAF] " s))
)

(defun SBS:acad () (vlax-get-acad-object))
(defun SBS:doc () (vla-get-ActiveDocument (SBS:acad)))
(defun SBS:plot () (vla-get-Plot (SBS:doc)))
(defun SBS:layouts () (vla-get-Layouts (SBS:doc)))
(defun SBS:active-layout () (vla-get-ActiveLayout (SBS:doc)))

(defun SBS:safe-get (obj prop / r)
  (setq r (vl-catch-all-apply 'vlax-get-property (list obj prop)))
  (if (vl-catch-all-error-p r) nil r)
)

(defun SBS:safe-put (obj prop val / r)
  (setq r (vl-catch-all-apply 'vlax-put-property (list obj prop val)))
  (not (vl-catch-all-error-p r))
)

(defun SBS:replace-all (new old s / p)
  (while (setq p (vl-string-search old s))
    (setq s (strcat (substr s 1 p) new (substr s (+ p (strlen old) 1))))
  )
  s
)

(defun SBS:sanitize-filename (s / bad i ch out)
  (if (or (null s) (= s "")) (setq s "SHEET"))
  (setq bad '("\\" "/" ":" "*" "?" "\"" "<" ">" "|"))
  (foreach ch bad (setq s (SBS:replace-all "-" ch s)))
  (setq s (vl-string-trim " .\t\r\n" s))
  (while (vl-string-search "  " s)
    (setq s (SBS:replace-all " " "  " s))
  )
  (if (= s "") "SHEET" s)
)

(defun SBS:pad3 (n / s)
  (setq s (itoa n))
  (cond
    ((= (strlen s) 1) (strcat "00" s))
    ((= (strlen s) 2) (strcat "0" s))
    (T s)
  )
)

(defun SBS:dwg-base (/ n)
  (setq n (getvar "DWGNAME"))
  (if (and n (/= n ""))
    (vl-filename-base n)
    "Drawing"
  )
)

(defun SBS:unique-file (path / base ext n try)
  (if (not (findfile path))
    path
    (progn
      (setq base (strcat (vl-filename-directory path) "\\" (vl-filename-base path)))
      (setq ext (vl-filename-extension path))
      (setq n 2)
      (while (findfile (setq try (strcat base "_" (itoa n) ext)))
        (setq n (1+ n))
      )
      try
    )
  )
)

(defun SBS:browse-folder (title / sh fld self path)
  (setq sh (vl-catch-all-apply 'vlax-create-object (list "Shell.Application")))
  (if (vl-catch-all-error-p sh)
    nil
    (progn
      (setq fld (vl-catch-all-apply 'vlax-invoke-method (list sh 'BrowseForFolder 0 title 0)))
      (if (or (vl-catch-all-error-p fld) (null fld))
        (setq path nil)
        (progn
          (setq self (vlax-get-property fld 'Self))
          (setq path (vlax-get-property self 'Path))
          (vlax-release-object self)
          (vlax-release-object fld)
        )
      )
      (vlax-release-object sh)
      path
    )
  )
)

(defun SBS:variant->list (v)
  (cond
    ((= (type v) 'VARIANT) (SBS:variant->list (vlax-variant-value v)))
    ((= (type v) 'SAFEARRAY) (vlax-safearray->list v))
    (T v)
  )
)

(defun SBS:pt2 (p)
  (list (car p) (cadr p) 0.0)
)

(defun SBS:2d-array (p / a)
  (setq a (vlax-make-safearray vlax-vbDouble '(0 . 1)))
  (vlax-safearray-fill a (list (float (car p)) (float (cadr p))))
  a
)

(defun SBS:wcs->dcs (p)
  (trans (SBS:pt2 p) 0 2)
)

;;; -----------------------------
;;; CTB / profile helpers
;;; -----------------------------
(defun SBS:bundle-root (/ f)
  (setq f (findfile "SheetBySadaf.lsp"))
  (if f (vl-filename-directory f) nil)
)

(defun SBS:ctb-source-dir (/ saved r candidate)
  ;; Prefer a source folder remembered from a previous SCTBINSTALL run.
  (setq saved (getenv "SHEETBYSADAF_CTB_DIR"))
  (cond
    ((and saved (findfile (strcat saved "\\ARCH_200.ctb")))
      saved
    )
    ;; If the LSP is in an AutoCAD support/trusted path, resolve its sibling CTB folder.
    ((and (setq r (SBS:bundle-root))
          (findfile (strcat r "\\CTB\\ARCH_200.ctb")))
      (setq candidate (strcat r "\\CTB"))
      (setenv "SHEETBYSADAF_CTB_DIR" candidate)
      candidate
    )
    ;; Robust fallback: no manual copying required. Ask once for the bundled CTB folder
    ;; (or the package root), remember it, then SCTBINSTALL copies the files itself.
    (T
      (SBS:msg "Select the bundled CTB folder (or the SHEET by SADAF package folder).")
      (setq candidate (SBS:browse-folder "SHEET by SADAF — Select bundled CTB folder or package folder"))
      (cond
        ((and candidate (findfile (strcat candidate "\\ARCH_200.ctb")))
          (setenv "SHEETBYSADAF_CTB_DIR" candidate)
          candidate
        )
        ((and candidate (findfile (strcat candidate "\\CTB\\ARCH_200.ctb")))
          (setq candidate (strcat candidate "\\CTB"))
          (setenv "SHEETBYSADAF_CTB_DIR" candidate)
          candidate
        )
        (T nil)
      )
    )
  )
)

(defun SBS:plot-style-dir (/ acad prefs files p)
  (setq acad (SBS:acad))
  (setq prefs (vla-get-Preferences acad))
  (setq files (vla-get-Files prefs))
  (setq p (SBS:safe-get files 'PrinterStyleSheetPath))
  p
)

(defun SBS:profile-ctb (key)
  (cdr (assoc key *SBS:CTB-PROFILES*))
)

(defun SBS:profile-menu (/ ans)
  (initget "Current ARCH50 ARCH100 ARCH200 ARCH300 ARCH300ALT ARCH500 SITE500 STRUCT COMMERCIAL VIEW")
  (setq ans
    (getkword
      "\nCTB profile [Current/ARCH50/ARCH100/ARCH200/ARCH300/ARCH300ALT/ARCH500/SITE500/STRUCT/COMMERCIAL/VIEW] <Current>: "
    )
  )
  (cond
    ((or (null ans) (= ans "Current")) nil)
    ((= ans "ARCH50") "ARCH_50")
    ((= ans "ARCH100") "ARCH_100")
    ((= ans "ARCH200") "ARCH_200")
    ((= ans "ARCH300") "ARCH_300")
    ((= ans "ARCH300ALT") "ARCH_300_ALT")
    ((= ans "ARCH500") "ARCH_500")
    ((= ans "SITE500") "SITE_500")
    ((= ans "STRUCT") "STRUCT_A4")
    ((= ans "COMMERCIAL") "COMMERCIAL_A3")
    ((= ans "VIEW") "VIEW")
  )
)

(defun SBS:apply-profile (layout key / ctb r)
  (if (null key)
    T
    (progn
      (setq ctb (SBS:profile-ctb key))
      (if (null ctb)
        (progn (SBS:msg (strcat "Unknown CTB profile: " key)) nil)
        (progn
          (setq r (vl-catch-all-apply 'vla-put-StyleSheet (list layout ctb)))
          (if (vl-catch-all-error-p r)
            (progn
              (SBS:msg (strcat "Could not apply " ctb ". Run SCTBINSTALL first or install the CTB manually."))
              nil
            )
            (progn
              (SBS:safe-put layout 'PlotWithPlotStyles :vlax-true)
              (SBS:safe-put layout 'PlotWithLineweights :vlax-true)
              (vl-catch-all-apply 'vla-RefreshPlotDeviceInfo (list layout))
              T
            )
          )
        )
      )
    )
  )
)

(defun C:SCTBINSTALL (/ src dst copied failed skipped overwrite pair fn s d)
  (setq src (SBS:ctb-source-dir))
  (setq dst (SBS:plot-style-dir))
  (if (or (null src) (null dst))
    (SBS:msg "Could not resolve the bundled CTB folder or AutoCAD Plot Styles folder.")
    (progn
      (initget "Overwrite Skip")
      (setq overwrite (getkword "\nExisting SHEET by SADAF CTB files [Overwrite/Skip] <Overwrite>: "))
      (if (null overwrite) (setq overwrite "Overwrite"))
      (setq copied 0 failed 0 skipped 0)
      (foreach pair *SBS:CTB-PROFILES*
        (setq fn (cdr pair))
        (setq s (strcat src "\\" fn))
        (setq d (strcat dst "\\" fn))
        (cond
          ((not (findfile s)) (setq failed (1+ failed)))
          ((and (findfile d) (= overwrite "Skip")) (setq skipped (1+ skipped)))
          (T
            (if (findfile d) (vl-file-delete d))
            (if (vl-file-copy s d)
              (setq copied (1+ copied))
              (setq failed (1+ failed))
            )
          )
        )
      )
      (SBS:msg (strcat "CTB install/update complete. Copied/updated: " (itoa copied) ", skipped: " (itoa skipped) ", failed: " (itoa failed)))
      (SBS:msg (strcat "Plot Styles folder: " dst))
    )
  )
  (princ)
)

(defun C:SCTB (/ key lay old)
  (setq lay (SBS:active-layout))
  (setq old (SBS:safe-get lay 'StyleSheet))
  (SBS:msg (strcat "Current CTB: " (if old old "<none>")))
  (setq key (SBS:profile-menu))
  (if key
    (if (SBS:apply-profile lay key)
      (SBS:msg (strcat "Applied profile " key " -> " (SBS:profile-ctb key)))
    )
    (SBS:msg "CTB unchanged.")
  )
  (princ)
)

;;; -----------------------------
;;; Geometry / detection helpers
;;; -----------------------------
(defun SBS:bbox (ename / obj mn mx r)
  (setq obj (vlax-ename->vla-object ename))
  (setq r (vl-catch-all-apply 'vla-GetBoundingBox (list obj 'mn 'mx)))
  (if (vl-catch-all-error-p r)
    nil
    (progn
      (setq mn (SBS:variant->list mn))
      (setq mx (SBS:variant->list mx))
      (list mn mx)
    )
  )
)

(defun SBS:box-width (b) (- (car (cadr b)) (car (car b))))
(defun SBS:box-height (b) (- (cadr (cadr b)) (cadr (car b))))
(defun SBS:box-center (b)
  (list
    (/ (+ (car (car b)) (car (cadr b))) 2.0)
    (/ (+ (cadr (car b)) (cadr (cadr b))) 2.0)
    0.0
  )
)

(defun SBS:effective-name (obj / r)
  (setq r (SBS:safe-get obj 'EffectiveName))
  (if r r (SBS:safe-get obj 'Name))
)

(defun SBS:closed-p (obj / r)
  (setq r (SBS:safe-get obj 'Closed))
  (= r :vlax-true)
)

(defun SBS:nearly (a b tol)
  (<= (abs (- a b)) tol)
)

(defun SBS:record (e / b)
  (setq b (SBS:bbox e))
  (if b
    (list e b (SBS:box-center b) (SBS:box-width b) (SBS:box-height b))
    nil
  )
)

(defun SBS:record-ename (r) (nth 0 r))
(defun SBS:record-box (r) (nth 1 r))
(defun SBS:record-center (r) (nth 2 r))
(defun SBS:record-width (r) (nth 3 r))
(defun SBS:record-height (r) (nth 4 r))

(defun SBS:detect-blocks (seed / obj nm ss i e o rec out)
  (setq obj (vlax-ename->vla-object seed))
  (setq nm (SBS:effective-name obj))
  (if (and nm (setq ss (ssget "_X" '((0 . "INSERT") (410 . "Model")))))
    (progn
      (setq i 0 out nil)
      (repeat (sslength ss)
        (setq e (ssname ss i))
        (setq o (vlax-ename->vla-object e))
        (if (= (strcase (SBS:effective-name o)) (strcase nm))
          (if (setq rec (SBS:record e)) (setq out (cons rec out)))
        )
        (setq i (1+ i))
      )
      (reverse out)
    )
    nil
  )
)

(defun SBS:detect-polylines (seed / sobj sb sw sh tol ss i e o b w h rec out)
  (setq sobj (vlax-ename->vla-object seed))
  (setq sb (SBS:bbox seed))
  (if (null sb)
    nil
    (progn
      (setq sw (SBS:box-width sb) sh (SBS:box-height sb))
      ;; 1.5% dimensional tolerance + a small absolute floor.
      (setq tol (max 0.01 (* (max sw sh) 0.015)))
      (setq ss (ssget "_X" '((0 . "LWPOLYLINE,POLYLINE") (410 . "Model"))))
      (if ss
        (progn
          (setq i 0 out nil)
          (repeat (sslength ss)
            (setq e (ssname ss i))
            (setq o (vlax-ename->vla-object e))
            (if (SBS:closed-p o)
              (progn
                (setq b (SBS:bbox e))
                (if b
                  (progn
                    (setq w (SBS:box-width b) h (SBS:box-height b))
                    (if (and (SBS:nearly w sw tol) (SBS:nearly h sh tol))
                      (if (setq rec (SBS:record e)) (setq out (cons rec out)))
                    )
                  )
                )
              )
            )
            (setq i (1+ i))
          )
          (reverse out)
        )
        nil
      )
    )
  )
)

(defun SBS:detect-sheets (seed / obj oname)
  (setq obj (vlax-ename->vla-object seed))
  (setq oname (vla-get-ObjectName obj))
  (cond
    ((= oname "AcDbBlockReference")
      (SBS:msg (strcat "Detection mode: matching title block / block reference '" (SBS:effective-name obj) "'."))
      (SBS:detect-blocks seed)
    )
    ((or (= oname "AcDbPolyline") (= oname "AcDb2dPolyline") (= oname "AcDb3dPolyline"))
      (SBS:msg "Detection mode: matching closed polyline by sheet dimensions.")
      (SBS:detect-polylines seed)
    )
    (T
      (SBS:msg "Selected object is not a block or polyline. Try selecting the title block or outer sheet frame.")
      nil
    )
  )
)

;;; Row-aware sorting: top rows first, then left to right.
(defun SBS:sort-records (records / sorted remaining first row rest y0 h tol r rows)
  (setq remaining
    (vl-sort records
      '(lambda (a b)
        (> (cadr (SBS:record-center a)) (cadr (SBS:record-center b)))
      )
    )
  )
  (setq rows nil)
  (while remaining
    (setq first (car remaining))
    (setq remaining (cdr remaining))
    (setq y0 (cadr (SBS:record-center first)))
    (setq h (max 1e-9 (SBS:record-height first)))
    (setq tol (* h 0.45))
    (setq row (list first) rest nil)
    (foreach r remaining
      (if (<= (abs (- (cadr (SBS:record-center r)) y0)) tol)
        (setq row (cons r row))
        (setq rest (cons r rest))
      )
    )
    (setq row
      (vl-sort row
        '(lambda (a b)
          (< (car (SBS:record-center a)) (car (SBS:record-center b)))
        )
      )
    )
    (setq rows (append rows row))
    (setq remaining (reverse rest))
  )
  rows
)

(defun SBS:highlight-records (records / ss)
  (setq ss (ssadd))
  (foreach r records (ssadd (SBS:record-ename r) ss))
  (sssetfirst nil ss)
  ss
)

;;; -----------------------------
;;; Attribute / file naming
;;; -----------------------------
(defun SBS:block-attributes (ename / obj v a out)
  (setq obj (vlax-ename->vla-object ename))
  (if (= (vla-get-ObjectName obj) "AcDbBlockReference")
    (if (= (SBS:safe-get obj 'HasAttributes) :vlax-true)
      (progn
        (setq v (vl-catch-all-apply 'vlax-invoke (list obj 'GetAttributes)))
        (if (not (vl-catch-all-error-p v))
          (progn
            (setq a (SBS:variant->list v))
            (foreach x a
              (setq out
                (cons
                  (cons (strcase (vla-get-TagString x)) (vla-get-TextString x))
                  out
                )
              )
            )
          )
        )
      )
    )
  )
  out
)

(defun SBS:sheet-label-from-attrs (ename / attrs tags v)
  (setq attrs (SBS:block-attributes ename))
  (setq tags
    '("SHEET_NO" "SHEETNO" "SHEET-NO" "SHEET NO" "SHEET_NUMBER" "SHEETNUMBER"
      "NUMBER" "NO" "NUM" "SHEET" "DRAWING_NO" "DRAWINGNO" "DWG_NO" "DWGNO")
  )
  (while (and tags (null v))
    (if (assoc (car tags) attrs) (setq v (cdr (assoc (car tags) attrs))))
    (setq tags (cdr tags))
  )
  (if v (SBS:sanitize-filename v) nil)
)

(defun SBS:sheet-output-name (record idx prefix / lab)
  (setq lab (SBS:sheet-label-from-attrs (SBS:record-ename record)))
  (if lab
    (strcat prefix "_" (SBS:pad3 idx) "_" lab ".pdf")
    (strcat prefix "_S" (SBS:pad3 idx) ".pdf")
  )
)

;;; -----------------------------
;;; Plot state helpers
;;; -----------------------------
(defun SBS:capture-layout-state (lay)
  (list
    (cons 'StyleSheet (SBS:safe-get lay 'StyleSheet))
    (cons 'PlotType (SBS:safe-get lay 'PlotType))
    (cons 'CenterPlot (SBS:safe-get lay 'CenterPlot))
    (cons 'PlotWithPlotStyles (SBS:safe-get lay 'PlotWithPlotStyles))
    (cons 'PlotWithLineweights (SBS:safe-get lay 'PlotWithLineweights))
    (cons 'PlotWithTransparency (SBS:safe-get lay 'PlotWithTransparency))
  )
)

(defun SBS:restore-layout-state (lay state / p)
  (foreach p state
    (if (not (null (cdr p))) (SBS:safe-put lay (car p) (cdr p)))
  )
  (vl-catch-all-apply 'vla-RefreshPlotDeviceInfo (list lay))
)

(defun SBS:set-window (lay box / mn mx p1 p2 r)
  (setq mn (car box) mx (cadr box))
  (setq p1 (SBS:wcs->dcs mn))
  (setq p2 (SBS:wcs->dcs mx))
  (SBS:safe-put lay 'PlotType 4) ;; acWindow
  (setq r
    (vl-catch-all-apply
      'vla-SetWindowToPlot
      (list lay (SBS:2d-array p1) (SBS:2d-array p2))
    )
  )
  (if (vl-catch-all-error-p r) nil T)
)

(defun SBS:plot-to-file (filename / p r)
  (setq p (SBS:plot))
  (SBS:safe-put p 'QuietErrorMode :vlax-true)
  (setq r (vl-catch-all-apply 'vla-PlotToFile (list p filename)))
  (if (vl-catch-all-error-p r) nil r)
)


;;; -----------------------------
;;; Multi-sheet PDF publishing helpers (v0.1.3)
;;; -----------------------------
(defun SBS:dwg-full-path (/ pre nm)
  (setq pre (getvar "DWGPREFIX"))
  (setq nm (getvar "DWGNAME"))
  (if (and pre nm (/= nm "") (findfile (strcat pre nm)))
    (strcat pre nm)
    nil
  )
)

(defun SBS:output-mode (/ m)
  (initget "Separate Single")
  (setq m (getkword "\nFinal PDF output [Separate/Single] <Separate>: "))
  (if (or (null m) (= m "Separate")) "Separate" "Single")
)

(defun SBS:temp-token ()
  ;; Millisecond-ish session token derived from DATE; safe for names and filenames.
  (vl-string-subst "_" "." (rtos (getvar "DATE") 2 8))
)

(defun SBS:write-dsd (dsdpath dwgpath sheetdefs pdfpath / fp sh idx outdir)
  ;; sheetdefs item = (displayName layoutName setupName)
  (setq fp (open dsdpath "w"))
  (if (null fp)
    nil
    (progn
      (write-line "[DWF6Version]" fp)
      (write-line "Ver=1" fp)
      (write-line "[DWF6MinorVersion]" fp)
      (write-line "MinorVer=1" fp)
      (setq idx 1)
      (foreach sh sheetdefs
        (write-line
          (strcat "[DWF6Sheet:" (SBS:sanitize-filename (car sh)) "-" (SBS:pad3 idx) "]") fp)
        (write-line (strcat "DWG=" dwgpath) fp)
        (write-line (strcat "Layout=" (cadr sh)) fp)
        (write-line (strcat "Setup=" (if (nth 2 sh) (nth 2 sh) "")) fp)
        (write-line (strcat "OriginalSheetPath=" dwgpath) fp)
        (write-line "Has Plot Port=0" fp)
        (write-line "Has3DDWF=0" fp)
        (setq idx (1+ idx))
      )
      (setq outdir (vl-filename-directory pdfpath))
      (write-line "[Target]" fp)
      (write-line "Type=6" fp) ;; 6 = multi-sheet PDF
      (write-line (strcat "DWF=" pdfpath) fp)
      (write-line (strcat "OUT=" outdir "\\") fp)
      (write-line "PWD=" fp)
      (write-line "[PdfOptions]" fp)
      (write-line "IncludeHyperlinks=TRUE" fp)
      (write-line "CreateBookmarks=TRUE" fp)
      (write-line "CaptureFontsInDrawing=TRUE" fp)
      (write-line "ConvertTextToGeometry=FALSE" fp)
      (write-line "VectorResolution=1200" fp)
      (write-line "RasterResolution=400" fp)
      (write-line "[AutoCAD Block Data]" fp)
      (write-line "IncludeBlockInfo=0" fp)
      (write-line "BlockTmplFilePath=" fp)
      (write-line "[SheetSet Properties]" fp)
      (write-line "IsSheetSet=FALSE" fp)
      (write-line "IsHomogeneous=FALSE" fp)
      (write-line "SheetSet Name=" fp)
      (write-line "NoOfCopies=1" fp)
      (write-line "PlotStampOn=FALSE" fp)
      (write-line "ViewFile=FALSE" fp)
      (write-line "JobID=0" fp)
      (write-line "SelectionSetName=" fp)
      (write-line "AcadProfile=" fp)
      (write-line "CategoryName=" fp)
      (write-line (strcat "LogFilePath=" (vl-filename-directory dsdpath) "\\SheetBySadaf_Publish.csv") fp)
      (write-line "IncludeLayer=TRUE" fp)
      (write-line "LineMerge=FALSE" fp)
      (write-line "CurrentPrecision=" fp)
      (write-line "PromptForDwfName=FALSE" fp)
      (write-line "GenerateDwfName=TRUE" fp)
      (write-line "PwdProtectPublishedDWF=FALSE" fp)
      (write-line "PromptForPwd=FALSE" fp)
      (write-line "RepublishingMarkups=FALSE" fp)
      (write-line "PublishSheetSetMetadata=FALSE" fp)
      (write-line "PublishSheetMetadata=FALSE" fp)
      (write-line "3DDWFOptions=0 1" fp)
      (close fp)
      T
    )
  )
)

(defun SBS:publish-dsd (dsdpath / oldfd oldce oldbg r)
  (setq oldfd (getvar "FILEDIA"))
  (setq oldce (getvar "CMDECHO"))
  (setq oldbg (getvar "BACKGROUNDPLOT"))
  (setvar "FILEDIA" 0)
  (setvar "CMDECHO" 0)
  (setvar "BACKGROUNDPLOT" 0)
  (setq r (vl-catch-all-apply 'vl-cmdf (list "_.-PUBLISH" dsdpath)))
  (setvar "BACKGROUNDPLOT" oldbg)
  (setvar "CMDECHO" oldce)
  (setvar "FILEDIA" oldfd)
  (not (vl-catch-all-error-p r))
)

(defun SBS:delete-plotconfig-by-name (name / pcs pc)
  (setq pcs (vla-get-PlotConfigurations (SBS:doc)))
  (setq pc (vl-catch-all-apply 'vla-Item (list pcs name)))
  (if (not (vl-catch-all-error-p pc))
    (vl-catch-all-apply 'vla-Delete (list pc))
  )
)

(defun SBS:create-model-page-setups (records modelLay / pcs token i r pc nm defs created)
  ;; Creates temporary named Model page setups, one window per detected sheet.
  ;; Each setup inherits printer/media/rotation/CTB/scale from current Model plot settings.
  (setq pcs (vla-get-PlotConfigurations (SBS:doc)))
  (setq token (SBS:temp-token))
  (setq i 1 defs nil created nil)
  (foreach r records
    (setq nm (strcat "SBS_TMP_" token "_" (SBS:pad3 i)))
    (SBS:delete-plotconfig-by-name nm)
    (setq pc (vl-catch-all-apply 'vla-Add (list pcs nm :vlax-true)))
    (if (vl-catch-all-error-p pc)
      (setq defs nil)
      (progn
        (vl-catch-all-apply 'vla-CopyFrom (list pc modelLay))
        (SBS:safe-put pc 'PlotType 4) ;; Window
        (SBS:safe-put pc 'CenterPlot :vlax-true)
        (if (SBS:set-window pc (SBS:record-box r))
          (progn
            (setq created (cons nm created))
            (setq defs
              (append defs
                (list (list (strcat "Sheet-" (SBS:pad3 i)) "Model" nm))))
          )
          (setq defs nil)
        )
      )
    )
    (setq i (1+ i))
  )
  (list defs created)
)

(defun SBS:cleanup-plotconfigs (names)
  (foreach nm names (SBS:delete-plotconfig-by-name nm))
)

(defun SBS:publish-model-single (records lay folder prefix / dwg pdf dsd setups defs created ok)
  (setq dwg (SBS:dwg-full-path))
  (if (null dwg)
    (progn
      (SBS:msg "Single multi-page PDF needs the DWG to be saved first. Save the drawing, then run SPLOT again.")
      nil
    )
    (progn
      (setq pdf (SBS:unique-file (strcat folder "\\" prefix ".pdf")))
      (setq dsd (strcat (getvar "TEMPPREFIX") "SheetBySadaf_" (SBS:temp-token) ".dsd"))
      (setq setups (SBS:create-model-page-setups records lay))
      (setq defs (car setups))
      (setq created (cadr setups))
      (if (or (null defs) (/= (length defs) (length records)))
        (progn
          (SBS:cleanup-plotconfigs created)
          (SBS:msg "Could not prepare all temporary page setups for multi-sheet publishing.")
          nil
        )
        (progn
          (if (SBS:write-dsd dsd dwg defs pdf)
            (progn
              (SBS:msg (strcat "Publishing " (itoa (length records)) " sheets into one PDF..."))
              (setq ok (SBS:publish-dsd dsd))
            )
            (setq ok nil)
          )
          (SBS:cleanup-plotconfigs created)
          (if (findfile dsd) (vl-file-delete dsd))
          (if ok
            (progn (SBS:msg (strcat "Multi-sheet PDF finished: " pdf)) T)
            (progn (SBS:msg "Multi-sheet publish failed. Try Separate output and send the Command Line message for diagnosis.") nil)
          )
        )
      )
    )
  )
)

(defun SBS:publish-layouts-single (layouts folder prefix / dwg pdf dsd defs i l ok)
  (setq dwg (SBS:dwg-full-path))
  (if (null dwg)
    (progn
      (SBS:msg "Single multi-page PDF needs the DWG to be saved first. Save the drawing, then run SPLOT again.")
      nil
    )
    (progn
      (setq pdf (SBS:unique-file (strcat folder "\\" prefix ".pdf")))
      (setq dsd (strcat (getvar "TEMPPREFIX") "SheetBySadaf_" (SBS:temp-token) ".dsd"))
      (setq defs nil i 1)
      (foreach l layouts
        (setq defs
          (append defs
            (list (list (vla-get-Name l) (vla-get-Name l) ""))))
        (setq i (1+ i))
      )
      (if (SBS:write-dsd dsd dwg defs pdf)
        (progn
          (SBS:msg (strcat "Publishing " (itoa (length layouts)) " layouts into one PDF..."))
          (setq ok (SBS:publish-dsd dsd))
        )
        (setq ok nil)
      )
      (if (findfile dsd) (vl-file-delete dsd))
      (if ok
        (progn (SBS:msg (strcat "Multi-sheet PDF finished: " pdf)) T)
        (progn (SBS:msg "Multi-sheet publish failed. Try Separate output and send the Command Line message for diagnosis.") nil)
      )
    )
  )
)

;;; -----------------------------
;;; Model-space batch plot
;;; -----------------------------
(defun SBS:plot-model (/ doc lay oldstate oldbg seed records n ans folder prefix key outmode i r box fn ok fail result)
  (setq doc (SBS:doc))
  (setq lay (vla-Item (SBS:layouts) "Model"))
  (vla-put-ActiveLayout doc lay)

  (SBS:msg "Select the FIRST sheet frame or title block in Model Space.")
  (setq seed (car (entsel "\nSelect first sheet frame/title block: ")))
  (if (null seed)
    (SBS:msg "Cancelled.")
    (progn
      (setq records (SBS:detect-sheets seed))
      (if (or (null records) (= (length records) 0))
        (SBS:msg "No matching sheets were detected.")
        (progn
          (setq records (SBS:sort-records records))
          (setq n (length records))
          (SBS:highlight-records records)
          (SBS:msg (strcat (itoa n) " matching sheet(s) detected and highlighted."))
          (initget "Yes No")
          (setq ans (getkword "\nPlot these sheets? [Yes/No] <Yes>: "))
          (if (or (null ans) (= ans "Yes"))
            (progn
              (setq folder (SBS:browse-folder "SHEET by SADAF — Select PDF output folder"))
              (if (null folder)
                (SBS:msg "No output folder selected. Cancelled.")
                (progn
                  (setq prefix (getstring T (strcat "\nPDF filename prefix <" (SBS:dwg-base) ">: ")))
                  (if (= prefix "") (setq prefix (SBS:dwg-base)))
                  (setq prefix (SBS:sanitize-filename prefix))

                  (setq key (SBS:profile-menu))
                  (setq oldstate (SBS:capture-layout-state lay))
                  (if (or (null key) (SBS:apply-profile lay key))
                    (progn
                      ;; Ask at the last decision point, immediately before output begins.
                      (setq outmode (SBS:output-mode))
                      (if (= outmode "Single")
                        (SBS:publish-model-single records lay folder prefix)
                        (progn
                          (setq oldbg (getvar "BACKGROUNDPLOT"))
                          (setvar "BACKGROUNDPLOT" 0)
                          (setq i 1 ok 0 fail 0)
                          (foreach r records
                            (setq box (SBS:record-box r))
                            (setq fn
                              (SBS:unique-file
                                (strcat folder "\\" (SBS:sheet-output-name r i prefix))
                              )
                            )
                            (if (and (SBS:set-window lay box)
                                     (SBS:plot-to-file fn))
                              (progn
                                (setq ok (1+ ok))
                                (princ (strcat "\n  [" (itoa i) "/" (itoa n) "] OK  " fn))
                              )
                              (progn
                                (setq fail (1+ fail))
                                (princ (strcat "\n  [" (itoa i) "/" (itoa n) "] FAILED  " fn))
                              )
                            )
                            (setq i (1+ i))
                          )
                          (setvar "BACKGROUNDPLOT" oldbg)
                          (SBS:msg (strcat "Batch plot finished. Success: " (itoa ok) ", Failed: " (itoa fail) "."))
                          (SBS:msg (strcat "Output: " folder))
                        )
                      )
                      (SBS:restore-layout-state lay oldstate)
                    )
                    (progn
                      (SBS:restore-layout-state lay oldstate)
                      (SBS:msg "CTB profile could not be applied. Plot cancelled.")
                    )
                  )
                )
              )
            )
            (SBS:msg "Plot cancelled.")
          )
          (sssetfirst nil nil)
        )
      )
    )
  )
)

;;; -----------------------------
;;; Layout batch plot
;;; -----------------------------
(defun SBS:layout-list (/ col out l)
  (setq col (SBS:layouts))
  (vlax-for l col
    (if (/= (strcase (vla-get-Name l)) "MODEL")
      (setq out (cons l out))
    )
  )
  (vl-sort out '(lambda (a b) (< (vla-get-TabOrder a) (vla-get-TabOrder b))))
)

(defun SBS:plot-layouts (/ doc layouts folder prefix useown key outmode oldbg current i n l oldstate states fn ok fail)
  (setq doc (SBS:doc))
  (setq layouts (SBS:layout-list))
  (if (null layouts)
    (SBS:msg "No Paper Space layouts found.")
    (progn
      (setq folder (SBS:browse-folder "SHEET by SADAF — Select PDF output folder"))
      (if folder
        (progn
          (setq prefix (getstring T (strcat "\nPDF filename prefix <" (SBS:dwg-base) ">: ")))
          (if (= prefix "") (setq prefix (SBS:dwg-base)))
          (setq prefix (SBS:sanitize-filename prefix))
          (initget "Own Override")
          (setq useown (getkword "\nCTB handling [Own/Override] <Own>: "))
          (if (or (null useown) (= useown "Own"))
            (setq key nil)
            (setq key (SBS:profile-menu))
          )
          (setq current (vla-get-ActiveLayout doc))
          ;; Capture all states first because Single publish needs all layouts configured simultaneously.
          (setq states nil)
          (foreach l layouts
            (setq states (append states (list (cons l (SBS:capture-layout-state l)))))
            (if key (SBS:apply-profile l key))
          )
          ;; Ask at the last decision point, immediately before output begins.
          (setq outmode (SBS:output-mode))
          (if (= outmode "Single")
            (SBS:publish-layouts-single layouts folder prefix)
            (progn
              (setq oldbg (getvar "BACKGROUNDPLOT"))
              (setvar "BACKGROUNDPLOT" 0)
              (setq i 1 n (length layouts) ok 0 fail 0)
              (foreach l layouts
                (vla-put-ActiveLayout doc l)
                (setq fn
                  (SBS:unique-file
                    (strcat folder "\\" prefix "_" (SBS:pad3 i) "_" (SBS:sanitize-filename (vla-get-Name l)) ".pdf")
                  )
                )
                (if (SBS:plot-to-file fn)
                  (progn (setq ok (1+ ok)) (princ (strcat "\n  [" (itoa i) "/" (itoa n) "] OK  " fn)))
                  (progn (setq fail (1+ fail)) (princ (strcat "\n  [" (itoa i) "/" (itoa n) "] FAILED  " fn)))
                )
                (setq i (1+ i))
              )
              (setvar "BACKGROUNDPLOT" oldbg)
              (SBS:msg (strcat "Layout batch plot finished. Success: " (itoa ok) ", Failed: " (itoa fail) "."))
              (SBS:msg (strcat "Output: " folder))
            )
          )
          ;; Restore all layout plot states and active tab.
          (foreach pair states
            (SBS:restore-layout-state (car pair) (cdr pair))
          )
          (vla-put-ActiveLayout doc current)
        )
        (SBS:msg "No output folder selected. Cancelled.")
      )
    )
  )
)

;;; -----------------------------
;;; Experimental Layout creation
;;; -----------------------------
;;; This beta creates layout tabs from detected Model sheets only when a
;;; Paper Space template layout already exists. The template supplies paper,
;;; printer and CTB settings. A Fit viewport is then created and zoomed to
;;; the detected Model sheet. This deliberately avoids changing the Model.
(defun SBS:choose-template-layout (/ ls i names ans)
  (setq ls (SBS:layout-list))
  (if (null ls)
    nil
    (progn
      (princ "\nAvailable template layouts:")
      (setq i 1)
      (foreach l ls
        (princ (strcat "\n  " (itoa i) ". " (vla-get-Name l)))
        (setq i (1+ i))
      )
      (setq ans (getint "\nTemplate layout number: "))
      (if (and ans (>= ans 1) (<= ans (length ls)))
        (nth (1- ans) ls)
        nil
      )
    )
  )
)

(defun SBS:copy-layout-plot-settings (src dst)
  ;; Layout.CopyFrom accepts a PlotConfiguration/Layout object.
  (not
    (vl-catch-all-error-p
      (vl-catch-all-apply 'vla-CopyFrom (list dst src))
    )
  )
)

(defun SBS:delete-paper-viewports (/ ss i e)
  ;; Delete paper-space viewport entities except viewport #1 (overall paperspace viewport).
  (setq ss (ssget "_X" (list '(0 . "VIEWPORT") (cons 410 (getvar "CTAB")))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq e (ssname ss i))
        (if (/= (cdr (assoc 69 (entget e))) 1) (entdel e))
        (setq i (1+ i))
      )
    )
  )
)

(defun SBS:create-one-layout (name template box / doc lays lay oldlcv vp r mn mx)
  (setq doc (SBS:doc))
  (setq lays (SBS:layouts))
  (setq oldlcv (getvar "LAYOUTCREATEVIEWPORT"))
  (setvar "LAYOUTCREATEVIEWPORT" 0)
  (setq lay (vla-Add lays name))
  (SBS:copy-layout-plot-settings template lay)
  (vla-put-ActiveLayout doc lay)
  (SBS:delete-paper-viewports)
  ;; MVIEW Fit fills the printable paper area using the copied page setup.
  (setq r (vl-catch-all-apply 'vl-cmdf (list "_.MVIEW" "_Fit")))
  (setvar "LAYOUTCREATEVIEWPORT" oldlcv)
  (if (vl-catch-all-error-p r)
    nil
    (progn
      (setq vp (entlast))
      (setq mn (car box) mx (cadr box))
      (vl-cmdf "_.MSPACE")
      (vl-cmdf "_.ZOOM" "_W" (SBS:pt2 mn) (SBS:pt2 mx))
      (vl-cmdf "_.PSPACE")
      ;; Lock created viewport where possible.
      (if vp
        (SBS:safe-put (vlax-ename->vla-object vp) 'DisplayLocked :vlax-true)
      )
      lay
    )
  )
)

(defun C:SLAYOUT (/ doc model seed records template prefix i r name made fail current createResult)
  (setq doc (SBS:doc))
  (setq current (vla-get-ActiveLayout doc))
  (setq model (vla-Item (SBS:layouts) "Model"))
  (vla-put-ActiveLayout doc model)
  (setq template (SBS:choose-template-layout))
  (if (null template)
    (SBS:msg "SLAYOUT needs at least one existing Paper Space layout to use as the page-setup template in this beta.")
    (progn
      (setq seed (car (entsel "\nSelect first sheet frame/title block in Model Space: ")))
      (if seed
        (progn
          (setq records (SBS:sort-records (SBS:detect-sheets seed)))
          (if records
            (progn
              (SBS:highlight-records records)
              (SBS:msg (strcat (itoa (length records)) " sheets detected."))
              (initget "Yes No")
              (if (/= (getkword "\nCreate layouts for all detected sheets? [Yes/No] <Yes>: ") "No")
                (progn
                  (setq prefix (getstring T "\nLayout prefix <SHEET>: "))
                  (if (= prefix "") (setq prefix "SHEET"))
                  (setq prefix (SBS:sanitize-filename prefix))
                  (setq i 1 made 0 fail 0)
                  (foreach r records
                    (setq name (strcat prefix "-" (SBS:pad3 i)))
                    (setq createResult
                      (vl-catch-all-apply 'SBS:create-one-layout (list name template (SBS:record-box r))))
                    (if (or (vl-catch-all-error-p createResult) (null createResult))
                      (setq fail (1+ fail))
                      (setq made (1+ made))
                    )
                    (setq i (1+ i))
                  )
                  (SBS:msg (strcat "Layout creation finished. Created: " (itoa made) ", Failed: " (itoa fail) "."))
                )
              )
              (sssetfirst nil nil)
            )
          )
        )
      )
    )
  )
  (if current (vla-put-ActiveLayout doc current))
  (princ)
)

;;; -----------------------------
;;; Main command / settings
;;; -----------------------------
(defun C:SPLOT (/ src mk)
  (SBS:msg (strcat "SHEET by SADAF v" *SBS:VERSION*))
  (initget "Model Layouts")
  (setq src (getkword "\nSource [Model/Layouts] <Model>: "))
  (if (or (null src) (= src "Model"))
    (progn
      (initget "Yes No")
      (setq mk (getkword "\nCreate separate Layouts first? [Yes/No] <No>: "))
      (if (= mk "Yes")
        (C:SLAYOUT)
        (SBS:plot-model)
      )
    )
    (SBS:plot-layouts)
  )
  (princ)
)

(defun C:SSET (/ lay ctb cfg media rot pdir)
  (setq lay (SBS:active-layout))
  (setq ctb (SBS:safe-get lay 'StyleSheet))
  (setq cfg (SBS:safe-get lay 'ConfigName))
  (setq media (SBS:safe-get lay 'CanonicalMediaName))
  (setq rot (SBS:safe-get lay 'PlotRotation))
  (setq pdir (SBS:plot-style-dir))
  (SBS:msg (strcat "Version: " *SBS:VERSION*))
  (princ (strcat "\n  Tab:       " (vla-get-Name lay)))
  (princ (strcat "\n  Plotter:   " (if cfg cfg "<unknown>")))
  (princ (strcat "\n  Media:     " (if media media "<unknown>")))
  (princ (strcat "\n  CTB:       " (if ctb ctb "<none>")))
  (princ (strcat "\n  Rotation:  " (if rot (itoa rot) "<unknown>")))
  (princ (strcat "\n  CTB path:  " (if pdir pdir "<unknown>")))
  (princ "\n  Commands:  SPLOT / SCTB / SCTBINSTALL / SLAYOUT / SSET")
  (princ)
)

(SBS:msg (strcat "Loaded v" *SBS:VERSION* ". Type SPLOT to start."))
(princ)
